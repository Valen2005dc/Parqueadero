
package estructurasdatos;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Stack;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Vale
 */
public class Parqueadero extends javax.swing.JFrame {

    String placa;
    String TipoVehiculo;
    int hora;
    int horamin;
    String horatot;
    int Saldos=0;
    DefaultTableModel mod = new DefaultTableModel();
    LinkedList<Parqueadero> car = new LinkedList<Parqueadero>();
    Stack<Parqueadero> motos = new Stack<>();
    Stack<Parqueadero> carros = new Stack<>();
    
    public Parqueadero() {
        initComponents();
        String ids [] = {"Id","Placa","Tipo","HoraIng","Saldo"};
        
        mod.setColumnIdentifiers(ids);
        jTable1.setModel(mod);
        
    }
    public static void AddRowToJTable(Object[] dataRow){
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.addRow(dataRow);
    }
    
    
    
    
    private JButton jButton2;
    private JButton jButton3;
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        buttonGroup6 = new javax.swing.ButtonGroup();
        buttonGroup7 = new javax.swing.ButtonGroup();
        jTextField2 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        NumVehiculo = new javax.swing.JLabel();
        jCheckBox3 = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        
        
        
        
        
        jButton2 = new JButton("Cerrar");
        jButton2.setBackground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jButton2.setForeground(new java.awt.Color(255, 255, 255)); // Blanco
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                // Cerrar el programa
                System.exit(0);
            }
        });
        jButton2.setBounds(220, 250, 80, 30);
        getContentPane().add(jButton2);
        
        // crear nuevo Label
        javax.swing.JLabel labelHora = new javax.swing.JLabel();
        labelHora.setBorder(javax.swing.BorderFactory.createTitledBorder("Hora actual"));
        labelHora.setFont(new java.awt.Font("Tahoma", 0, 14)); // tamaño de fuente 14
        labelHora.setHorizontalAlignment(javax.swing.SwingConstants.CENTER); // alinear al centro
        // agregar labelHora al jPanel1
        jPanel1.add(labelHora);
        labelHora.setBounds(360, 10, 140, 50); // posición y tamaño del label
        
        // actualizar la hora cada segundo usando un nuevo Thread
        new Thread(() -> {
                while (true) {
                            java.time.LocalDateTime now = java.time.LocalDateTime.now();
                            String horaActual = String.format("%02d:%02d:%02d", now.getHour(), now.getMinute(), now.getSecond());
                            labelHora.setText(horaActual);
                            try { Thread.sleep(1000); } catch (InterruptedException ex) {}
                             }
                }).start();
        
        
        
        
        
                
        jButton3 = new javax.swing.JButton();
        jButton3.setText("Retirar");
        jButton3 = new JButton("Retirar");
   
    jButton3.setBounds(380, 200, 79, 30);
    getContentPane().add(jButton3);
    jButton3.setBackground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jButton3.setForeground(new java.awt.Color(255, 255, 255)); // Blanco
            
        
        
        
        
        

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Parqueadero-Insertar"));

        jLabel1.setText("Ingrese datos del vehiculo:");

        jButton1.setText("Ingresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
            
            
            
                        
        });
        
        
        
        
        

        jLabel2.setText("Placa");

        jLabel3.setText("Tipo de vehiculo");

        jLabel4.setText("Hora de ingreso");

        jLabel5.setText("Numero de vehiculo:");

        jCheckBox1.setText("Carro");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("Moto");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner1StateChanged(evt);
            }
        });

        jLabel6.setText(":");

        jSpinner2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner2StateChanged(evt);
            }
        });

        NumVehiculo.setText("0");

        jCheckBox3.setText("Bicicleta");
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });
        
        
        //Cambiar el color de fondo del panel
        jPanel1.setBackground(new java.awt.Color(230, 230, 230));
        
        //Cambiar el color de los labels y botones
        
        jLabel1.setForeground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jLabel2.setForeground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jLabel3.setForeground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jLabel4.setForeground(new java.awt.Color(255, 87, 51)); // Gris claro
        jLabel5.setForeground(new java.awt.Color(255, 87, 51)); // Gris claro
        jLabel6.setForeground(new java.awt.Color(255, 87, 51)); // Gris claro
        jButton1.setBackground(new java.awt.Color(255, 87, 51)); // Naranja oscuro
        jButton1.setForeground(new java.awt.Color(255, 255, 255)); // Blanco
        jCheckBox1.setForeground(new java.awt.Color(102, 102, 102)); // Gris claro
        jCheckBox2.setForeground(new java.awt.Color(102, 102, 102)); // Gris claro
        jCheckBox3.setForeground(new java.awt.Color(102, 102, 102)); // Gris claro
        
        
        //Cambiar el color de la tabla
        jTable1.setBackground(new java.awt.Color(240, 240, 255));
        jTable1.setForeground(new java.awt.Color(60, 60, 80));
        

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox1)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jCheckBox2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                                        .addComponent(jCheckBox3)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton1))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NumVehiculo))
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(71, 71, 71))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(NumVehiculo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox2)
                    .addComponent(jButton1)
                    .addComponent(jCheckBox3))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Tabla de visualizacion"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Numero", "Placa", "Tipo de vehiculo", "Hora de ingreso", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jSpinner1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner1StateChanged
        int x=Integer.parseInt(jSpinner1.getValue().toString());
        if(x>23){
            jSpinner1.setValue(23);
        }
        if(x<0){
            jSpinner1.setValue(0);
        }
            
    }//GEN-LAST:event_jSpinner1StateChanged

    private void jSpinner2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner2StateChanged
        int x=Integer.parseInt(jSpinner2.getValue().toString());
        if(x>59){
            jSpinner2.setValue(59);
        }
        if(x<0){
            jSpinner2.setValue(0);
        }
    }//GEN-LAST:event_jSpinner2StateChanged

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        jCheckBox1.setSelected(false);
        jCheckBox3.setSelected(false);
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        if (jTextField1.getText().equals("") || (!jCheckBox1.isSelected() && !jCheckBox2.isSelected() && !jCheckBox3.isSelected())) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese todos los datos necesarios", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
        
        Parqueadero x=new Parqueadero();
        int cam;
        //Hora Actual
        LocalDateTime ahora= LocalDateTime.now();
        int minutos = ahora.getMinute();
        int horas = ahora.getHour();
        cam=Integer.parseInt(NumVehiculo.getText());
        x.placa=jTextField1.getText();
        if(jCheckBox1.isSelected()){
            x.TipoVehiculo="Carro";
        }
        if(jCheckBox2.isSelected()){
            x.TipoVehiculo="Moto";
        }
        if(jCheckBox3.isSelected()){
            x.TipoVehiculo="Bicicleta";
        }
       
        x.hora=(int) jSpinner1.getValue();
        x.horamin=(int) jSpinner2.getValue();
         x.horatot=String.valueOf(x.hora)+":"+String.valueOf(x.horamin);
        //Calcular saldo
        int minutopar=(x.hora*60)+x.horamin;
        int minutosact=minutos+(horas*60);
        for (int i = minutopar; i < minutosact; i++) {
            if(x.TipoVehiculo=="Carro"){
                x.Saldos=x.Saldos+60;
            }
            if(x.TipoVehiculo=="Moto"){
                x.Saldos=x.Saldos+30;
            }
            if(x.TipoVehiculo=="Bicicleta"){
                x.Saldos=x.Saldos+20;
            }
        }
         //Ingresar a lista
         car.add(x);
        
        mod.addRow(new Object[] {cam,car.getLast().placa,car.getLast().TipoVehiculo,car.getLast().horatot,car.getLast().Saldos});
        //PREPARAR PARA INGRESAR NUEVAMENTE
        cam+=1;
        NumVehiculo.setText(String.valueOf(cam));
        jTextField1.setText("");
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
        jSpinner1.setValue(0);
        jSpinner2.setValue(0);
        System.out.println(horas);
        System.out.println(minutos);
        
       
    }//GEN-LAST:event_jButton1ActionPerformed
    
    
    

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    
    
    

    
 
    
    
    
    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Parqueadero().setVisible(true);
            }
        });
    }
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel NumVehiculo;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.ButtonGroup buttonGroup6;
    private javax.swing.ButtonGroup buttonGroup7;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private static javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    
    
    // End of variables declaration//GEN-END:variables
}
