/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructurasdatos;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

/**
 *
 * @author LABSIS
 */
public class EstructurasDatos {

    public class Vehiculo {
    private String placa;
    private String tipoVehiculo;
    private LocalDateTime horaIngreso;
    private int saldo;

    public Vehiculo(String placa, String tipoVehiculo, LocalDateTime horaIngreso) {
        this.placa = placa;
        this.tipoVehiculo = tipoVehiculo;
        this.horaIngreso = horaIngreso;
        this.saldo = 0;
    }

    public String getPlaca() {
        return placa;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public LocalDateTime getHoraIngreso() {
        return horaIngreso;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
}

public class Parqueadero {
    private LinkedList<Vehiculo> vehiculos;

    public Parqueadero() {
        this.vehiculos = new LinkedList<>();
    }

    public void agregarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public void eliminarVehiculo(Vehiculo vehiculo) {
        vehiculos.remove(vehiculo);
    }

    public int calcularSaldo(Vehiculo vehiculo, LocalDateTime horaSalida) {
        int horas = (int) ChronoUnit.HOURS.between(vehiculo.getHoraIngreso(), horaSalida);
        int saldo = 0;
        if (vehiculo.getTipoVehiculo().equals("Carro")) {
            saldo = horas * 2000;
        } else if (vehiculo.getTipoVehiculo().equals("Moto")) {
            saldo = horas * 1000;
        } else if (vehiculo.getTipoVehiculo().equals("Bicicleta")) {
            saldo = horas * 500;
        }
        vehiculo.setSaldo(saldo);
        return saldo;
    }

    public void generarReporte() {
        System.out.println("Placa\tTipo\tHora ingreso\tSaldo");
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println(vehiculo.getPlaca() + "\t" + vehiculo.getTipoVehiculo() + "\t" + vehiculo.getHoraIngreso() + "\t" + vehiculo.getSaldo());
        }
    }
}
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
